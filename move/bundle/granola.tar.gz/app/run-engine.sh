#!/bin/sh
# Bring up the Granola SC engine on the Move: sclang(gr-boot.scd) + scsynth, as clients
# of the system jackd. Run on the device. Leaves sclang + scsynth running in the background;
# the headless controller then drives it over OSC.
#
# Granola ships NO SuperCollider bundle. It runs on PoundHard's — the same install puts
# both on the Move (poundhard/install.sh), and that runtime carries sclang, scsynth and
# the sc3-plugins UGens, of which Granola needs JPverb. It is named, not searched for:
# if it is not there the engine does not start, and says why.
set -e
GR=/data/UserData/granola
GR_SC_HOME=/data/UserData/poundhard
for f in bin/sclang bin/scsynth share/sclang_conf.yaml plugins/JPverb.so; do
    if [ ! -e "$GR_SC_HOME/$f" ]; then
        echo "[engine] FATAL: $GR_SC_HOME/$f is missing — install PoundHard's SC runtime (poundhard/install.sh)" >&2
        exit 1
    fi
done
export GR_SC_HOME GR_HOME="$GR"
echo "[engine] SC runtime: $GR_SC_HOME"

# A launch from the appliance menu has HOME unset; sclang then tries to mkdir
# /.local/share/SuperCollider (filesystem root) and fails -> Server.default is nil ->
# the engine never boots. Point HOME at a writable dir.
export HOME=/data/UserData
# Only sclang reads this. scsynth carries RT file capabilities, so the loader ignores
# LD_LIBRARY_PATH for it and uses the RPATH baked in by PoundHard's bundle instead.
export LD_LIBRARY_PATH=$GR_SC_HOME/lib
export SC_JACK_DEFAULT_OUTPUTS=system          # server out -> system:playback
export SC_JACK_DEFAULT_INPUTS=system
export SC_PLUGIN_PATH=$GR_SC_HOME/plugins      # backup to gr-boot's ugenPluginsPath

# SERVER: scsynth, NOT supernova — and this is measured, not a preference.
#
# The JPverb_supernova.so shipped in the bundles on this device does not register its
# UGen: booting supernova and loading a SynthDef that uses JPverb gives
#   "Cannot load synth <name>: Unit generator JPverbRaw not installed"
# and the node is never created, while the identical test under scsynth builds the
# synth and runs it. Granola's master reverb IS JPverb, so supernova would cost the
# reverb outright — a change to the ported sound, not a performance trade.
#
# The load is well within one core: eight GrainBuf clouds, two send effects and a
# limiter.
export GR_THREADS=0                            # scsynth: see above
export GR_SR=44100                             # jackd-move runs at 44.1k
export GR_BLOCK=128                            # match its 128-frame period
# Telemetry / handshake target = the local headless controller. 57141, NOT PoundHard's
# 57140: only one takeover runs at a time, but a stale sibling controller must not be
# able to eat our telemetry.
export CONTROLLER_HOST=127.0.0.1
export CONTROLLER_PORT="${CONTROLLER_PORT:-57141}"
export PATH=$GR_SC_HOME/bin:$PATH
LOGS=$GR/logs; mkdir -p "$LOGS"
ENGLOG=$LOGS/engine.log

# jackd belongs to jackd-move.service. It is not just the audio server: it owns
# /dev/ablspi0.0, so the screen, the pads and every LED go through it, and it outlives
# any one appliance. The engine never starts, restarts or adopts one — it checks the
# system's server is there and refuses to run if it is not.
if ! pgrep -x jackd >/dev/null 2>&1; then
    echo "[engine] FATAL: jackd is not running — start jackd-move.service" >&2
    exit 1
fi
echo "[engine] jackd present (move driver)"

echo "[engine] starting sclang (gr-boot.scd) — pinned to cores 0-2"
# setsid: detach from whatever launched us. Under the appliance launcher there is no tty
# and this changes nothing, but it is also how the stack is started from an ssh session
# during development — and there SIGHUP on logout would otherwise take the engine down
# a few seconds after it came up, which looks exactly like a boot failure.
setsid taskset 0x7 "$GR_SC_HOME/bin/sclang" -l "$GR_SC_HOME/share/sclang_conf.yaml" "$GR/sc/gr-boot.scd" \
    > "$ENGLOG" 2>&1 < /dev/null &
echo "[engine] sclang pid=$!  (log: $ENGLOG)"
echo "[engine] waiting for boot ..."
i=0
while [ $i -lt 60 ]; do
    grep -q "granola. engine ready\|SuperCollider 3 server ready" "$ENGLOG" 2>/dev/null && break
    grep -qi "ERROR\|FAILURE\|Exception" "$ENGLOG" 2>/dev/null && { echo "[engine] error:"; tail -n 20 "$ENGLOG"; exit 1; }
    i=$((i+1)); sleep 1
done
echo "[engine] --- log tail ---"; tail -n 12 "$ENGLOG"

# Core pinning: scsynth on cores 1-2, sclang on core 0, core 3 left to the SPI/display
# driver. jackd is the system's and is placed by move-rt-tune, not by us.
for p in $(pgrep -f "$GR_SC_HOME/bin/scsynth"); do taskset -pc 1-2 "$p" >/dev/null 2>&1; done
for p in $(pgrep -f "$GR_SC_HOME/bin/sclang"); do taskset -pc 0 "$p" >/dev/null 2>&1; done

for p in $(pgrep -x scsynth); do
    echo "[engine] $(cat /proc/$p/comm 2>/dev/null) sched: $(chrt -p $p 2>/dev/null | tr '\n' ' ')"
done
