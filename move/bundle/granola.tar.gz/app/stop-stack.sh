#!/bin/sh
# Tear the Granola stack DOWN completely. Run by the appliance launcher on Back (and
# before any appliance starts), so nothing survives into the next session.
#
# Clients are asked to leave BEFORE they are made to. scsynth is a JACK client:
# SIGKILL gives it no chance to unregister, and the server then refuses new client
# connections while it reaps the corpse — jackd alive and holding /dev/ablspi0.0,
# screen and pads dead until the JACK watchdog restarts it.
#
# jackd itself is NEVER touched here. It runs the native `move` driver and owns the
# display, the pads and the jogwheel; the launcher draws through it.
GR=/data/UserData/granola

# Only OUR engine: PoundHard's is a sibling on the same ports and has its own stop
# route. Match by the boot file on the command line (sclang) and by our plugin dir
# (scsynth is started with -U $GR/plugins:...).
ours() {
    for p in $(pgrep -x sclang 2>/dev/null) $(pgrep -x scsynth 2>/dev/null); do
        case "$(tr '\0' ' ' < "/proc/$p/cmdline" 2>/dev/null)" in
            *"$GR/"*) echo "$p" ;;
        esac
    done
}

# 0. Stop the launch scripts before what they launch, or they start it again. Bracketed
#    patterns never match this script; skip our own pid and our caller's too.
kill_script() {
    for pid in $(pgrep -f "$1" 2>/dev/null); do
        [ "$pid" = "$$" ] && continue
        [ "$pid" = "$PPID" ] && continue
        kill -9 "$pid" 2>/dev/null
    done
}
kill_script "granola/run-stac[k].sh"
kill_script "granola/run-engin[e].sh"
kill_script "granola/run-controlle[r].sh"

# 1. Ask. The controller first, so it stops talking to an engine that is leaving.
pkill -TERM -f "granola[.]headless" 2>/dev/null

# 2. The server: /quit over OSC, NOT a signal. SIGTERM ends scsynth without an orderly
#    JACK shutdown — measured: every exit left jackd logging a burst of "SuperCollider
#    was not finished" xruns while it evicted the client. /quit makes the server close
#    its JACK client itself. Only when the server is ours.
server_ours() {
    for p in $(pgrep -x scsynth 2>/dev/null); do
        case "$(tr '\0' ' ' < "/proc/$p/cmdline" 2>/dev/null)" in *"$GR/"*) return 0 ;; esac
    done
    return 1
}
if server_ours; then
    python3 -c 'import socket; socket.socket(socket.AF_INET, socket.SOCK_DGRAM).sendto(b"/quit\0\0\0,\0\0\0", ("127.0.0.1", 57110))'
    i=0
    while server_ours && [ "$i" -lt 30 ]; do sleep 0.1; i=$((i + 1)); done
fi

# 3. Then sclang, which holds no JACK client.
P=$(ours); [ -n "$P" ] && kill -TERM $P 2>/dev/null

# 4. Wait for them to actually go — this is what keeps JACK healthy. Up to 5s.
i=0
while [ -n "$(ours)" ] && [ "$i" -lt 50 ]; do
    sleep 0.1
    i=$((i + 1))
done

# 5. Insist, only on what is left. A surviving scsynth makes the next boot attach to an
#    orphan server: ready, zero nodes, no audio.
P=$(ours)
if [ -n "$P" ]; then
    echo "[stop] engine ignored TERM for 5s, forcing: $P"
    kill -9 $P 2>/dev/null
    sleep 0.3
fi
pkill -9 -f "granola[.]headless" 2>/dev/null

rm -f /dev/shm/SuperColliderServer_57110 2>/dev/null
# Drop the hand-off files so a stale grid can't flash on relaunch.
rm -f "$GR"/ipc/*.json "$GR"/ipc/ui_hb.txt 2>/dev/null
exit 0
