#!/bin/sh
# Launch the full Granola stack (engine + headless controller) non-blocking.
# Started by the appliance launcher (and again, harmlessly, by ui.js). Each sub-script
# daemonises its processes; we background them so the caller returns immediately.
GR=/data/UserData/granola
LOGS=$GR/logs; mkdir -p "$LOGS"
# IPC dir for control/status/heartbeat: a plain directory on /data.
if [ -L "$GR/ipc" ]; then rm -f "$GR/ipc"; fi
mkdir -p "$GR/ipc" "$GR/samples" "$GR/state" "$GR/projects" "$GR/harvest-tmp"

# Only ONE appliance runs at a time, and the SC ports are SHARED with PoundHard (57110
# server, 57120 sclang). The launcher runs every appliance's stop route before it starts
# one, so a foreign engine here means someone started us by hand over a running
# sibling. Refuse, rather than kill a JACK client out from under jackd: the sibling's
# own stop-stack.sh is the way to clear it.
for p in $(pgrep -x sclang 2>/dev/null) $(pgrep -x scsynth 2>/dev/null) $(pgrep -x supernova 2>/dev/null); do
    case "$(tr '\0' ' ' < "/proc/$p/cmdline" 2>/dev/null)" in
        *"$GR/"*) ;;                                 # ours
        "") ;;                                       # vanished
        *) echo "[stack] FATAL: a foreign SC engine is running (pid $p) — stop that appliance first" >&2
           exit 1 ;;
    esac
done

# A HALF-DEAD STACK IS WORSE THAN A DEAD ONE: the server can die on its own (JACK drops a
# client that misses its deadline) while sclang and the controller survive, and a guard
# that only asks whether OUR sclang exists then skips the engine start forever. An sclang
# with no server under it is wreckage — clear it.
if pgrep -f "$GR/sc/gr-boo[t].scd" >/dev/null 2>&1 && ! pgrep -x scsynth >/dev/null 2>&1; then
    echo "[stack] sclang is up but the server is gone — tearing the stack down first"
    sh "$GR/stop-stack.sh" >/dev/null 2>&1
fi

if ! pgrep -f "$GR/sc/gr-boo[t].scd" >/dev/null 2>&1; then
    rm -f /dev/shm/SuperColliderServer_57110 2>/dev/null   # a stale segment breaks World_New
    setsid nohup sh "$GR/run-engine.sh" > "$LOGS/stack_engine.log" 2>&1 < /dev/null &
fi

# Controller: starts in parallel — it pings the engine until ready.
if ! pgrep -f "granola[.]headless" >/dev/null 2>&1; then
    setsid nohup sh "$GR/run-controller.sh" > "$LOGS/controller.log" 2>&1 < /dev/null &
fi
